﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Challenge_4_Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
